package com.kliteseats.servlets;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/order")
public class OrderServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        String selectedMeals = request.getParameter("selectedMeals");
        request.setAttribute("selectedMeals", selectedMeals);
        RequestDispatcher dispatcher = request.getRequestDispatcher("order_confirmation.jsp");
        dispatcher.forward(request, response);
    }
}
