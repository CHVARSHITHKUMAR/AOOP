package com.kliteseats.servlets;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/uploadMenu")
public class UploadMenuServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        String menu = request.getParameter("menu");
        HttpSession session = request.getSession();
        session.setAttribute("menu", menu);
        response.sendRedirect("manager_dashboard.jsp");
    }
}
