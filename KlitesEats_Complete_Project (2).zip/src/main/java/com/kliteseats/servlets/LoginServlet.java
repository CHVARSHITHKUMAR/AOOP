package com.kliteseats.servlets;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        String role = request.getParameter("role");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        HttpSession session = request.getSession();
        if ("student".equals(role) && "student".equals(username) && "student123".equals(password)) {
            session.setAttribute("user", "student");
            response.sendRedirect("student_dashboard.jsp");
        } else if ("manager".equals(role) && "manager".equals(username) && "manager123".equals(password)) {
            session.setAttribute("user", "manager");
            response.sendRedirect("manager_dashboard.jsp");
        } else {
            response.sendRedirect("index.jsp?error=Invalid Credentials");
        }
    }
}
